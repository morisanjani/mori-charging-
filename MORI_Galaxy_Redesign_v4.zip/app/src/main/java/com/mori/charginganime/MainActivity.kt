package com.mori.charginganime

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import android.widget.FrameLayout
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var pendingSoundSlot = ""
    private val requestSound = 310
    private val requestCoreImage = 311
    private var preview: PlacementPreview? = null
    private var serviceStartRequested = false

    private val accent = Color.rgb(91, 157, 255)
    private val purple = Color.rgb(156, 105, 255)
    private val muted = Color.rgb(151, 166, 198)
    private val lightMode: Boolean get() = prefs.getBoolean("lightTheme", false)
    private val themes = arrayOf("کیهانی", "طوفان الکتریکی", "آب و رودخانه", "باران", "کریستال و یخ", "جنگل")
    private val themeKeys = arrayOf("cosmic", "storm", "water", "rain", "crystal", "forest")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mori", MODE_PRIVATE)
        migrateSettings()
        window.statusBarColor = Color.rgb(4, 6, 14)
        window.navigationBarColor = Color.rgb(4, 6, 14)
        window.decorView.systemUiVisibility = 0
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
        }
        showSplash()
    }

    private fun migrateSettings() {
        val version = prefs.getInt("settingsVersion", 0)
        if (version < 3) {
            // Earlier builds placed the core too low. Raise it for existing installs.
            prefs.edit().putInt("coreY", 14).apply()
        }
        if (version < 4) {
            // v4 uses coreSize as a diameter value, preserving a sane visual size.
            prefs.edit().putInt("coreSize", prefs.getInt("coreSize", 74).coerceIn(35, 120)).putInt("settingsVersion", 4).apply()
        }
    }

    private fun showSplash() {
        val splash = SplashView(this)
        setContentView(splash)
        ui.postDelayed({ render() }, 2750)
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun dp(value: Int): Int = dp(value.toFloat())

    private fun card(parent: LinearLayout, padding: Int = 16): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                if (lightMode) intArrayOf(Color.rgb(255, 255, 255), Color.rgb(232, 239, 250))
                else intArrayOf(Color.rgb(14, 22, 42), Color.rgb(9, 13, 27))).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), if (lightMode) Color.rgb(202, 215, 237) else Color.rgb(37, 57, 91))
            }
        }
        parent.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(7), 0, dp(7))
        })
        return box
    }

    private fun label(text: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        val resolved = if (lightMode) when (color) {
            Color.WHITE -> Color.rgb(26, 37, 59)
            Color.rgb(224, 231, 245) -> Color.rgb(41, 54, 78)
            Color.rgb(204, 214, 235) -> Color.rgb(51, 65, 92)
            Color.rgb(181, 194, 219) -> Color.rgb(75, 91, 119)
            Color.rgb(151, 180, 255), Color.rgb(148, 181, 255) -> Color.rgb(54, 83, 137)
            Color.rgb(105, 126, 164), Color.rgb(102, 119, 153), Color.rgb(105, 119, 145) -> Color.rgb(83, 99, 126)
            Color.GRAY -> Color.rgb(88, 101, 127)
            else -> color
        } else color
        setTextColor(resolved)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun section(parent: LinearLayout, text: String) {
        parent.addView(label(text, 14f, Color.rgb(151, 180, 255), true).apply {
            setPadding(dp(3), dp(14), dp(3), dp(7))
        })
    }

    private fun actionButton(text: String, primary: Boolean = false, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(if (lightMode && !primary) Color.rgb(31, 47, 75) else Color.WHITE)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            if (primary) intArrayOf(Color.rgb(40, 100, 190), Color.rgb(100, 77, 196))
            else if (lightMode) intArrayOf(Color.rgb(231, 239, 251), Color.rgb(215, 228, 246))
            else intArrayOf(Color.rgb(24, 39, 67), Color.rgb(19, 28, 49))).apply {
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), if (primary) Color.rgb(103, 154, 255) else if (lightMode) Color.rgb(195, 211, 235) else Color.rgb(47, 66, 104))
        }
        setOnClickListener { onClick() }
    }

    private fun addRowSwitch(parent: LinearLayout, title: String, key: String, default: Boolean, onChange: ((Boolean) -> Unit)? = null) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(5), 0, dp(5))
        }
        row.addView(label(title, 13f, Color.rgb(224, 231, 245)), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.addView(sw)
        parent.addView(row)
    }

    private fun addSlider(parent: LinearLayout, title: String, key: String, min: Int, max: Int, default: Int, unit: String = "") {
        val initial = prefs.getInt(key, default).coerceIn(min, max)
        val value = label("$title  $initial$unit", 12f, Color.rgb(204, 214, 235), true)
        value.setPadding(0, dp(10), 0, dp(1))
        parent.addView(value)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(52, 62, 82))
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val result = min + progress
                value.text = "$title  $result$unit"
                if (fromUser) prefs.edit().putInt(key, result).apply()
                preview?.invalidate()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        parent.addView(seek)
    }

    private fun render() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(12), dp(16), dp(28))
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val info = actionButton("ⓘ", false) { showInfo() }.apply { textSize = 19f; setPadding(dp(15), dp(8), dp(15), dp(8)) }
        header.addView(info)
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        titleBlock.addView(label("MORI", 29f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        titleBlock.addView(label("CHARGING ANIME", 12f, Color.rgb(148, 181, 255), true).apply { gravity = Gravity.CENTER })
        header.addView(titleBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(View(this), LinearLayout.LayoutParams(dp(42), dp(1)))
        root.addView(header)
        root.addView(label("NEBULA ENERGY SYSTEM", 10f, Color.rgb(105, 126, 164)).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(12)) })

        val controlCard = card(root, 14)
        addRowSwitch(controlCard, "فعال بودن MORI", "enabled", true) { enabled ->
            if (enabled) startMoriService() else {
                serviceStartRequested = false
                stopService(Intent(this, ChargingService::class.java))
            }
        }
        addRowSwitch(controlCard, "صدای رعدهای کوتاه حین شارژ", "arcSound", false)
        addRowSwitch(controlCard, "حالت کم‌نور هنگام خاموش بودن صفحه", "screenOff", true)
        addRowSwitch(controlCard, "حالت روشن رابط کاربری", "lightTheme", false) { render() }

        section(root, "پیش‌نمایش جایگاه روی صفحه گوشی")
        val previewCard = card(root, 10)
        preview = PlacementPreview(this, prefs).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(255))
        }
        previewCard.addView(preview)
        previewCard.addView(label("نشانگر آبی: محل شروع شارژ  •  نشانگر بنفش: مرکز انرژی", 10f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4))
        })
        previewCard.addView(label("برای جابه‌جایی، نشانگر را روی تصویر گوشی با انگشت بکش.", 11f, Color.rgb(181, 194, 219)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6))
        })

        section(root, "پروفایل‌های آماده")
        val presetScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val presets = listOf("طوفان" to "Storm", "کهکشان" to "Galaxy", "آرام" to "Calm", "حداقلی" to "Minimal", "AMOLED" to "AMOLED")
        presets.forEach { pair ->
            val chip = actionButton(pair.first, prefs.getString("preset", "Galaxy") == pair.second) {
                applyPreset(pair.second)
                render()
            }
            presetRow.addView(chip, LinearLayout.LayoutParams(dp(100), dp(48)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        presetScroll.addView(presetRow)
        root.addView(presetScroll)

        section(root, "ظاهر و موتور انرژی")
        val effectCard = card(root)
        val colors = listOf("تصادفی" to "random", "آبی" to "blue", "بنفش" to "purple", "یخی" to "ice", "طلایی" to "gold")
        effectCard.addView(label("رنگ انرژی", 12f, muted, true))
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        colors.forEach { (name, key) ->
            val dotColor = when (key) { "blue" -> accent; "purple" -> purple; "ice" -> Color.rgb(220, 247, 255); "gold" -> Color.rgb(255, 195, 86); else -> Color.WHITE }
            val chip = TextView(this).apply {
                text = "●  $name"
                textSize = 10f
                setTextColor(dotColor)
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(8), dp(6), dp(8))
                background = rounded(if (prefs.getString("color", "random") == key) Color.rgb(38, 58, 94) else Color.rgb(15, 23, 41), 11, Color.rgb(47, 67, 102))
                setOnClickListener { prefs.edit().putString("color", key).apply(); render() }
            }
            colorRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(7), dp(2), dp(4)) })
        }
        effectCard.addView(colorRow)
        addSlider(effectCard, "شدت نور", "intensity", 1, 5, 3)
        addSlider(effectCard, "تعداد شاخه‌های رعد", "branches", 2, 14, 7)
        addSlider(effectCard, "سرعت حرکت", "speed", 1, 10, 5)
        addSlider(effectCard, "تأخیر شروع پس از اتصال", "connectDelay", 0, 3000, 2400, " ms")
        addSlider(effectCard, "اندازه هسته (قطر)", "coreSize", 35, 120, 74, " dp")
        addRowSwitch(effectCard, "ذرات انرژی", "particles", true)
        addRowSwitch(effectCard, "موج و تپش هسته", "pulses", true)

        section(root, "تنظیم دقیق موقعیت")
        val positionCard = card(root)
        addSlider(positionCard, "موقعیت افقی هسته", "coreX", 5, 95, 50, "%")
        addSlider(positionCard, "موقعیت عمودی هسته", "coreY", 5, 90, 14, "%")
        addSlider(positionCard, "موقعیت افقی سوکت", "portX", 5, 95, 50, "%")
        addSlider(positionCard, "موقعیت عمودی سوکت", "portY", 5, 95, 94, "%")
        positionCard.addView(actionButton("بازنشانی موقعیت‌ها", false) {
            prefs.edit().putInt("coreX", 50).putInt("coreY", 14).putInt("portX", 50).putInt("portY", 94).apply()
            render()
        })

        section(root, "هسته و تصویر دلخواه")
        val imageCard = card(root)
        imageCard.addView(actionButton("انتخاب تصویر برای هسته", false) { pickCoreImage() })
        imageCard.addView(actionButton("حذف تصویر انتخاب‌شده", false) {
            prefs.edit().remove("coreImageUri").apply(); Toast.makeText(this, "تصویر هسته حذف شد", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(8), 0, dp(8)) })

        section(root, "سیستم صوتی")
        val soundCard = card(root)
        soundCard.addView(label("تم صوتی (مستقل از رنگ افکت)", 12f, muted, true))
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, themes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(themeKeys.indexOf(prefs.getString("soundTheme", "cosmic")).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putString("soundTheme", themeKeys[position]).apply()
            }
        }
        soundCard.addView(spinner)
        addSlider(soundCard, "بلندی صدای MORI", "soundVolume", 0, 100, 75, "%")
        soundCard.addView(soundRow("صدای اتصال", "start", "startSound"))
        soundCard.addView(soundRow("صدای محیط شارژ", "ambient", "ambientSound"))
        soundCard.addView(soundRow("صدای شارژ کامل", "complete", "endSound"))
        soundCard.addView(actionButton("بازنشانی فایل‌های صوتی انتخاب‌شده", false) {
            prefs.edit().remove("sound_start_uri").remove("sound_ambient_uri").remove("sound_complete_uri").apply()
            Toast.makeText(this, "صداهای پیش‌فرض دوباره فعال شدند", Toast.LENGTH_SHORT).show()
        })

        section(root, "اجرا و آزمایش")
        val actions = card(root)
        actions.addView(actionButton("تست کامل افکت و صدای اتصال", true) { ChargingService.showDemo(this) })
        actions.addView(actionButton("شروع سرویس شارژ MORI", false) { prefs.edit().putBoolean("enabled", true).apply(); startMoriService() }.apply { setPadding(0, dp(12), 0, dp(12)) })
        actions.addView(actionButton("توقف سرویس", false) {
            prefs.edit().putBoolean("enabled", false).apply()
            serviceStartRequested = false
            stopService(Intent(this, ChargingService::class.java))
            render()
        })
        actions.addView(actionButton("اجازه نمایش روی برنامه‌ها", false) {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "مجوز نمایش فعال است", Toast.LENGTH_SHORT).show()
        })
        root.addView(label("تنظیمات به‌صورت خودکار ذخیره می‌شوند", 10f, Color.rgb(102, 119, 153)).apply { gravity = Gravity.CENTER; setPadding(0, dp(13), 0, dp(4)) })
        root.addView(label("ساخته شده توسط MORI  •  sanjani.morteza@gmail.com", 10f, Color.rgb(105, 119, 145)).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(10)) })
        val frame = FrameLayout(this)
        frame.setBackgroundColor(if (lightMode) Color.rgb(241, 245, 252) else Color.rgb(4, 6, 14))
        frame.addView(NebulaBackground(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
        if (prefs.getBoolean("enabled", true) && Settings.canDrawOverlays(this) && !serviceStartRequested) {
            startMoriService()
        }
    }

    private fun rounded(color: Int, radiusDp: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat(); setStroke(dp(1), stroke)
    }

    private fun soundRow(title: String, slot: String, toggleKey: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        top.addView(label(title, 13f, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pick = actionButton("انتخاب فایل", false) { pickSound(slot) }
        top.addView(pick)
        row.addView(top)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val check = Switch(this).apply { isChecked = prefs.getBoolean(toggleKey, slot != "ambient") }
        check.setOnCheckedChangeListener { _, value -> prefs.edit().putBoolean(toggleKey, value).apply() }
        bottom.addView(check)
        bottom.addView(label("فعال", 11f, muted).apply { setPadding(dp(5), 0, dp(10), 0) })
        bottom.addView(actionButton("پخش آزمایشی", false) { MoriAudio.preview(this@MainActivity, slot, prefs) })
        row.addView(bottom)
        return row
    }

    private fun showInfo() {
        android.app.AlertDialog.Builder(this).setTitle("درباره MORI")
            .setMessage("MORI Charging Anime\nساخته شده توسط MORI\nsanjani.morteza@gmail.com\n\nافکت‌ها به‌صورت شفاف روی صفحه فعلی نمایش داده می‌شوند.")
            .setPositiveButton("باشه", null).show()
    }

    private fun pickSound(slot: String) {
        pendingSoundSlot = slot
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, requestSound)
    }

    private fun pickCoreImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, requestCoreImage)
    }

    @Deprecated("Legacy result path keeps this project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        when (requestCode) {
            requestSound -> {
                prefs.edit().putString("sound_${pendingSoundSlot}_uri", uri.toString()).apply()
                Toast.makeText(this, "فایل صوتی ذخیره شد", Toast.LENGTH_SHORT).show()
            }
            requestCoreImage -> {
                prefs.edit().putString("coreImageUri", uri.toString()).apply()
                Toast.makeText(this, "تصویر هسته ذخیره شد", Toast.LENGTH_SHORT).show()
                preview?.invalidate()
            }
        }
    }

    private fun applyPreset(preset: String) {
        val e = prefs.edit().putString("preset", preset)
        when (preset) {
            "Storm" -> e.putInt("intensity", 5).putInt("branches", 12).putInt("speed", 8).putInt("coreSize", 88).putBoolean("particles", true).putBoolean("pulses", true)
            "Galaxy" -> e.putInt("intensity", 3).putInt("branches", 7).putInt("speed", 5).putInt("coreSize", 74).putBoolean("particles", true).putBoolean("pulses", true)
            "Calm" -> e.putInt("intensity", 2).putInt("branches", 4).putInt("speed", 3).putInt("coreSize", 65).putBoolean("particles", true).putBoolean("pulses", true)
            "Minimal" -> e.putInt("intensity", 1).putInt("branches", 2).putInt("speed", 3).putInt("coreSize", 52).putBoolean("particles", false).putBoolean("pulses", false)
            "AMOLED" -> e.putInt("intensity", 1).putInt("branches", 2).putInt("speed", 2).putInt("coreSize", 48).putBoolean("particles", false).putBoolean("pulses", false)
        }
        e.apply()
    }

    private fun startMoriService() {
        if (!prefs.getBoolean("enabled", true)) prefs.edit().putBoolean("enabled", true).apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "ابتدا اجازه نمایش روی برنامه‌ها را فعال کن", Toast.LENGTH_LONG).show()
            return
        }
        val service = Intent(this, ChargingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        serviceStartRequested = true
    }

    override fun onResume() {
        super.onResume()
        if (::prefs.isInitialized && prefs.getBoolean("enabled", true) && Settings.canDrawOverlays(this) && !serviceStartRequested) {
            startMoriService()
        }
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }
}

private class PlacementPreview(context: android.content.Context, private val prefs: SharedPreferences) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val screen = RectF()
    private var active = "core"
    private var downX = 0f
    private var downY = 0f
    private fun dp(v: Float) = v * density
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val phoneW = min(w * .43f, dp(132f)); val phoneH = min(h - dp(16f), phoneW * 2.03f)
        val left = (w - phoneW) / 2f; val top = (h - phoneH) / 2f
        screen.set(left + dp(5f), top + dp(6f), left + phoneW - dp(5f), top + phoneH - dp(6f))
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(7, 11, 24); canvas.drawRoundRect(screen, dp(18f), dp(18f), paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2f); paint.color = Color.rgb(93, 120, 169); canvas.drawRoundRect(left, top, left + phoneW, top + phoneH, dp(22f), dp(22f), paint)
        paint.style = Paint.Style.FILL
        for (i in 0 until 28) {
            val x = screen.left + ((i * 37) % 97) / 97f * screen.width()
            val y = screen.top + ((i * 53) % 101) / 101f * screen.height()
            paint.color = Color.argb(80 + (i % 5) * 25, 115, 150, 210); canvas.drawCircle(x, y, dp(if (i % 5 == 0) 1.5f else .7f), paint)
        }
        paint.color = Color.rgb(25, 34, 58); canvas.drawRoundRect(screen.centerX() - dp(19f), screen.top + dp(4f), screen.centerX() + dp(19f), screen.top + dp(10f), dp(5f), dp(5f), paint)
        val coreX = screen.left + screen.width() * prefs.getInt("coreX", 50) / 100f
        val coreY = screen.top + screen.height() * prefs.getInt("coreY", 14) / 100f
        val portX = screen.left + screen.width() * prefs.getInt("portX", 50) / 100f
        val portY = screen.top + screen.height() * prefs.getInt("portY", 94) / 100f
        paint.color = Color.argb(65, 155, 112, 255); canvas.drawCircle(coreX, coreY, dp(17f), paint)
        paint.color = Color.rgb(156, 105, 255); canvas.drawCircle(coreX, coreY, dp(7f), paint)
        paint.color = Color.WHITE; canvas.drawCircle(coreX, coreY, dp(2.2f), paint)
        paint.color = Color.argb(60, 85, 165, 255); canvas.drawCircle(portX, portY, dp(12f), paint)
        paint.color = Color.rgb(82, 166, 255); canvas.drawCircle(portX, portY, dp(5.5f), paint)
        paint.color = Color.WHITE; canvas.drawCircle(portX, portY, dp(1.7f), paint)
        paint.color = Color.rgb(151, 180, 255); paint.textSize = dp(10f); paint.textAlign = Paint.Align.CENTER
        val coords = "CORE ${prefs.getInt("coreX", 50)}/${prefs.getInt("coreY", 14)}   •   PORT ${prefs.getInt("portX", 50)}/${prefs.getInt("portY", 94)}"
        canvas.drawText(coords, w / 2f, h - dp(6f), paint)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val coreX = screen.left + screen.width() * prefs.getInt("coreX", 50) / 100f
        val coreY = screen.top + screen.height() * prefs.getInt("coreY", 14) / 100f
        val portX = screen.left + screen.width() * prefs.getInt("portX", 50) / 100f
        val portY = screen.top + screen.height() * prefs.getInt("portY", 94) / 100f
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                active = if (hypot(event.x - portX, event.y - portY) < hypot(event.x - coreX, event.y - coreY)) "port" else "core"
                return true
            }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                if (screen.width() > 0 && screen.height() > 0) {
                    val x = (((event.x - screen.left) / screen.width()) * 100f).roundToInt().coerceIn(5, 95)
                    val y = (((event.y - screen.top) / screen.height()) * 100f).roundToInt()
                    if (active == "core") prefs.edit().putInt("coreX", x).putInt("coreY", y.coerceIn(5, 90)).apply()
                    else prefs.edit().putInt("portX", x).putInt("portY", y.coerceIn(5, 95)).apply()
                    invalidate()
                }
                return true
            }
        }
        return true
    }
}


private class NebulaBackground(private val context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private val stars = Array(110) { Pair(Math.random().toFloat(), Math.random().toFloat()) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (context.getSharedPreferences("mori", android.content.Context.MODE_PRIVATE).getBoolean("lightTheme", false)) return
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = RadialGradient(w * .13f, h * .22f, w * .75f,
            intArrayOf(Color.argb(28, 53, 105, 204), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint); paint.shader = null
        paint.shader = RadialGradient(w * .86f, h * .67f, w * .66f,
            intArrayOf(Color.argb(21, 112, 64, 190), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint); paint.shader = null
        stars.forEachIndexed { index, point ->
            paint.color = Color.argb(35 + (index % 6) * 17, 162, 190, 245)
            canvas.drawCircle(point.first * w, point.second * h, (if (index % 11 == 0) 1.3f else .65f) * density, paint)
        }
    }
}

private class SplashView(context: android.content.Context) : View(context) {
    private val start = android.os.SystemClock.uptimeMillis()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = Array(75) { Pair(Math.random().toFloat(), Math.random().toFloat()) }
    private val density = resources.displayMetrics.density
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val elapsed = android.os.SystemClock.uptimeMillis() - start
        val progress = ((elapsed - 480L).toFloat() / 1750f).coerceIn(0f, 1f)
        canvas.drawColor(Color.rgb(3, 5, 13))
        stars.forEachIndexed { index, pair ->
            p.color = Color.argb(70 + (index % 5) * 30, 150, 184, 255)
            canvas.drawCircle(pair.first * width, pair.second * height, (if (index % 8 == 0) 1.6f else .7f) * density, p)
        }
        val logoAlpha = (255 * (1f - progress)).toInt().coerceIn(0, 255)
        p.color = Color.argb(logoAlpha, 245, 248, 255); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); p.textSize = 44f * density
        canvas.drawText("MORI", width / 2f, height * .38f, p)
        p.color = Color.argb(logoAlpha, 123, 165, 255); p.textSize = 12f * density; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        canvas.drawText("CHARGING ANIME", width / 2f, height * .38f + 25f * density, p)
        val holeY = height * (1.18f - .72f * progress)
        val radius = (20f + 65f * progress) * density
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(width / 2f, holeY, radius * 1.8f,
            intArrayOf(Color.TRANSPARENT, Color.argb(90, 85, 91, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(width / 2f, holeY, radius * 1.8f, p); p.shader = null
        p.color = Color.rgb(12, 12, 25); canvas.drawCircle(width / 2f, holeY, radius * .72f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f * density
        p.color = Color.argb((190 * (1f - progress * .45f)).toInt(), 103, 146, 255)
        canvas.save(); canvas.rotate(elapsed * .045f, width / 2f, holeY)
        canvas.drawOval(width / 2f - radius * 1.25f, holeY - radius * .43f, width / 2f + radius * 1.25f, holeY + radius * .43f, p)
        canvas.restore(); p.style = Paint.Style.FILL
        if (elapsed > 2150L) {
            p.color = Color.argb(((elapsed - 2150L) * 255L / 450L).toInt().coerceIn(0, 255), 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        }
        if (elapsed < 2650) postInvalidateDelayed(32)
    }
}
