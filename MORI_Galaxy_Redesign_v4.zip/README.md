# MORI Charging Anime — Galaxy build

Android project (Kotlin, minSdk 26, targetSdk 35) for a transparent charging animation overlay.

## Included in this revision

- Custom dark/optional light MORI control screen.
- Custom adaptive launcher icon and a short black-hole logo opening animation.
- Touch-drag placement preview for the energy core and charging-port origin. The v3 migration moves the default core position higher to 14% from the top.
- Independent core position, port position and core-size controls; all settings persist automatically.
- Storm, Galaxy, Calm, Minimal and AMOLED presets.
- Transparent overlay: the actual app/home-screen content remains the background.
- A one-time connection bolt that travels from the charging-port position along a screen edge to the core, followed by a broad short-lived energy burst.
- Short, randomized, locally branching lightning around the core while charging (not full-screen repeated lines).
- Multi-layer black-hole/accretion-ring core, optional user-selected center image, particles and pulse controls.
- Battery-full transition, disconnect fade-out, and reduced-light low-motion rendering while the display is off (when enabled).
- Six original synthesized audio themes, connection/ambient/completion tracks, optional varied storm crackles, file picker overrides and per-slot previews.
- GitHub Actions workflow to build a debug APK.

## Build

Open the repository in GitHub and run **Actions → Build Mori APK → Run workflow**. The workflow uploads `Mori-Charging-Anime-debug-apk`.

## First run on Android

1. Install the debug APK.
2. Open MORI and grant **Display over other apps**.
3. Keep the MORI service enabled. The ongoing notification indicates the foreground service.
4. If the device manufacturer limits background services, allow MORI to run in the background / disable its battery restriction in system settings.
5. Use the preview to drag the purple core marker and blue charging-origin marker. These positions are saved automatically.
6. Run the test button before connecting the charger.

## Notes and limits

- Audio assets are original synthesized effects, not recordings of real thunder/water/forest. Users can replace each connection, ambient or completion sound with a file from the phone.
- Screen-off rendering is a low-light/low-motion overlay mode; Android/OEM policies may hide overlays on the lock screen or suspend the process. True always-on-display integration is not guaranteed.
- Overlay permissions, notification behavior, battery broadcasts and OEM battery management must be verified on the target phone. HyperOS may require manually allowing background autostart and unrestricted battery use.
- The source ZIP is not an APK. Compile it with the included GitHub Actions workflow and test the resulting APK on the device.


Version 4 patch: charging effect delay defaults to 2400 ms and is configurable (0–3000 ms); core setting is treated as diameter; selected core image refreshes live; AMOLED preset no longer overwrites the separate screen-off preference.
