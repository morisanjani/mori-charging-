package com.mori.charginganime

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.SharedPreferences

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private val colors = arrayOf("تصادفی", "آبی", "بنفش", "سفید یخی", "طلایی")
    private val colorValues = arrayOf("random", "blue", "purple", "ice", "gold")
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); prefs=getSharedPreferences("mori",MODE_PRIVATE); render() }
    private fun render(){
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(24)); setBackgroundColor(Color.rgb(5,7,15)) }
        val title=TextView(this).apply { text="MORI\nCHARGING ANIME"; textSize=26f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,0,0,dp(8)) }
        root.addView(title)
        val subtitle=TextView(this).apply{text="کنترل افکت انرژی";textSize=14f;setTextColor(Color.rgb(140,180,255));gravity=Gravity.CENTER;padding(0,0,0,dp(12))}
        root.addView(subtitle)
        addSwitch(root,"فعال بودن MORI","enabled",true)
        addSwitch(root,"صدای اتصال","startSound",true)
        addSwitch(root,"صدای شارژ کامل","endSound",true)
        addSwitch(root,"افکت کم‌نور هنگام خاموش بودن صفحه","screenOff",false)
        section(root,"پروفایل‌های آماده")
        val presets=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("Storm","Galaxy","Calm","Minimal","AMOLED").forEach { name-> presets.addView(button(name){applyPreset(name);render()}.apply{layoutParams=LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),dp(2),dp(2),dp(2))}}) }
        root.addView(presets)
        section(root,"رنگ انرژی")
        val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,colors);sp.setSelection(colorValues.indexOf(prefs.getString("color","random")).coerceAtLeast(0));sp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:View?,pos:Int,id:Long){prefs.edit().putString("color",colorValues[pos]).apply()}};root.addView(sp)
        slider(root,"شدت", "intensity",0,5,3);slider(root,"تراکم شاخه‌ها","branches",1,12,6);slider(root,"سرعت","speed",1,10,5);slider(root,"اندازه هسته","coreSize",30,120,65)
        section(root,"جایگاه هسته (درصد از صفحه)")
        slider(root,"موقعیت افقی هسته","coreX",10,90,50);slider(root,"موقعیت عمودی هسته","coreY",5,90,18)
        section(root,"نقطه شروع از پایین صفحه")
        slider(root,"موقعیت افقی سوکت","portX",5,95,50);slider(root,"ارتفاع نقطه شروع","portY",70,100,94)
        section(root,"صدا")
        addSwitch(root,"صدای محیط هنگام شارژ","ambientSound",false)
        addSwitch(root,"ذخیره تنظیمات","saveSettings",true)
        section(root,"دسترسی و اجرا")
        root.addView(button("اجازه نمایش روی برنامه‌ها"){if(!Settings.canDrawOverlays(this))startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))})
        root.addView(button("تست افکت"){ChargingService.showDemo(this)})
        root.addView(button("فعال‌سازی سرویس"){startService(Intent(this,ChargingService::class.java))})
        root.addView(button("توقف سرویس"){stopService(Intent(this,ChargingService::class.java))})
        section(root,"ⓘ")
        root.addView(TextView(this).apply{text="ساخته شده توسط MORI\nنسخه آزمایشی — سازگاری و مصرف انرژی باید روی دستگاه بررسی شود.";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER;padding(0,dp(8),0,dp(8))})
        setContentView(ScrollView(this).apply{addView(root)})
    }
    private fun View.padding(l:Int,t:Int,r:Int,b:Int){setPadding(dp(l),dp(t),dp(r),dp(b))}
    private fun section(parent:LinearLayout,s:String){parent.addView(TextView(this).apply{text=s;textSize=14f;setTextColor(Color.rgb(130,170,255));padding(0,dp(14),0,dp(5))})}
    private fun button(s:String,action:()->Unit)=Button(this).apply{text=s;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(22,38,64));setOnClickListener{action()}}
    private fun addSwitch(parent:LinearLayout,title:String,key:String,default:Boolean){val sw=Switch(this).apply{text=title;setTextColor(Color.WHITE);isChecked=prefs.getBoolean(key,default);padding(0,dp(5),0,dp(5))};sw.setOnCheckedChangeListener{_,c->prefs.edit().putBoolean(key,c).apply()};parent.addView(sw)}
    private fun slider(parent:LinearLayout,title:String,key:String,min:Int,max:Int,default:Int){parent.addView(TextView(this).apply{text="$title: ${prefs.getInt(key,default)}";tag=key;setTextColor(Color.LTGRAY);textSize=12f;padding(0,dp(8),0,0)});val seek=SeekBar(this).apply{this.max=max-min;progress=(prefs.getInt(key,default)-min).coerceIn(0,max-min)};seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){prefs.edit().putInt(key,p+min).apply();(parent.getChildAt(parent.childCount-2) as? TextView)?.text="$title: ${p+min}"};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}});parent.addView(seek)}
    private fun applyPreset(n:String){val e=prefs.edit();when(n){"Storm"->e.putInt("intensity",5).putInt("branches",12).putInt("speed",8).putInt("coreSize",80);"Galaxy"->e.putInt("intensity",3).putInt("branches",7).putInt("speed",5).putInt("coreSize",65);"Calm"->e.putInt("intensity",2).putInt("branches",4).putInt("speed",3).putInt("coreSize",55);"Minimal"->e.putInt("intensity",1).putInt("branches",2).putInt("speed",3).putInt("coreSize",45);"AMOLED"->e.putInt("intensity",0).putInt("branches",2).putInt("speed",2).putInt("coreSize",40).putBoolean("screenOff",true)};e.apply()}
}
