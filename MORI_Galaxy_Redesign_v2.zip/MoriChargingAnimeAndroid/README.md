# Mori Charging Anime

Android Kotlin overlay charging-effect prototype. Features the redesigned settings panel, preset profiles, configurable effect colors/intensity/branch density/speed/core size, and percentage-based core/socket positions. Build via the included GitHub Actions workflow (`Build Mori APK`).

This is a prototype. Audio theme/file-picker, touch-drag placement preview, icon/splash sequence, and reliable screen-off/AOD behavior are not yet implemented; test overlay and battery behavior on device.
