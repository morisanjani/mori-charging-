MORI Charging Anime - review and changes for this package

Base: MORI Galaxy Redesign v5.1 source ZIP.

Changes applied:
- Main UI header/title moved lower by adding extra top padding to the scroll content.
- Short charging strike control text simplified to "صدا".
- Short-strike audio toggle no longer restricted to the Storm sound theme; it uses the built-in short thunder samples with any selected sound profile.
- Port-to-core connection path retains the edge-route behavior but uses uneven, sharper lightning geometry and several irregular side forks.
- Added/adjusted GitHub Actions workflow for this ZIP's root project structure (not nested in a subfolder).

Review notes:
- This is source code, not an APK.
- Audio files are included in app/src/main/res/raw. The project includes six selectable audio themes with start/ambient/completion assets and three short-strike samples.
- A real Android build and device test could not be completed in this environment. The GitHub Actions workflow is included to build the APK.
