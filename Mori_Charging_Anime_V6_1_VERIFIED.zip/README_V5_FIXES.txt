MORI Galaxy Redesign v5 - fixes based on screenshots

Changes in this source revision:
- Default core position raised to 8% from the top; existing v4 installs migrate to this position.
- Default ambient audio enabled during migration; individual sound toggles remain editable.
- Connection start and connection sound wait for the user-configured delay (default 2400 ms, range 0-3000 ms).
- Disconnect, screen-off and full-charge state cancel a pending connection start.
- Demo/test connection start also observes the delay.
- Audio playback uses explicit sonification/media AudioAttributes.
- Connection bolt stroke is thinner and less outlined, with softer glow; local charging strikes are shorter.
- The trailing explanation sentence was removed from the About dialog.

Not compiled or tested on-device in this environment.
