MORI v5.1 directional lightning adjustment
- During ordinary charging, each lightning event now produces only 2 or 3 main short bolts.
- The main bolt directions are selected from randomized angular sectors, so they are not emitted radially from every side of the core.
- Each main bolt has only 1 or 2 short side branches.
- Directional bolts are shorter than the previous version.
- The branch-density setting affects whether a 2-bolt or 2/3-bolt burst is selected.
This is source-level modification only; APK compilation/device testing remains unverified.
