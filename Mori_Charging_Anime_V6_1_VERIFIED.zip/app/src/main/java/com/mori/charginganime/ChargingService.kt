package com.mori.charginganime

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.*
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.BatteryManager
import android.os.PowerManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.*
import kotlin.random.Random

class ChargingService : Service(), SharedPreferences.OnSharedPreferenceChangeListener {
    private var powerReceiver: BroadcastReceiver? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var overlay: EnergyView? = null
    private var wm: WindowManager? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var audio: MoriAudioController
    private val handler = Handler(Looper.getMainLooper())
    private var connected = false
    private var screenOff = false
    private var completed = false
    private var demo = false
    private var connectionPending = false
    private val connectionStartToken = Any()

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("mori", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(this)
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("MORI Charging Anime")
            .setContentText("افکت انرژی آماده است")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        audio = MoriAudioController(this, prefs)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        screenOff = !(getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        registerPowerReceiver()
        registerBatteryReceiver()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "MORI Charging", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun registerPowerReceiver() {
        powerReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_POWER_CONNECTED -> {
                        connected = true
                        completed = false
                        scheduleConnectionEffect()
                    }
                    Intent.ACTION_POWER_DISCONNECTED -> {
                        connected = false
                        completed = false
                        handler.removeCallbacksAndMessages(CONNECTION_TOKEN)
                        audio.stopAmbient()
                        fadeOut()
                    }
                    Intent.ACTION_SCREEN_OFF -> {
                        screenOff = true
                        handler.removeCallbacksAndMessages(CONNECTION_TOKEN)
                        audio.stopAmbient()
                        overlay?.setScreenOff(prefs.getBoolean("screenOff", true))
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        screenOff = false
                        overlay?.setScreenOff(false)
                        if (connected && !completed && overlay == null && prefs.getBoolean("enabled", true)) scheduleConnectionEffect()
                        if (connected && !completed && prefs.getBoolean("ambientSound", false)) audio.startAmbient()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(powerReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(powerReceiver, filter)
    }

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action != Intent.ACTION_BATTERY_CHANGED) return
                val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val full = status == BatteryManager.BATTERY_STATUS_FULL || (plugged && level >= scale)
                if (plugged) connected = true else connected = false
                if (plugged && full && connectionPending) {
                    connectionPending = false
                    handler.removeCallbacksAndMessages(connectionStartToken)
                }
                if (plugged && full && !completed && prefs.getBoolean("enabled", true)) {
                    handler.removeCallbacksAndMessages(CONNECTION_TOKEN)
                    completed = true
                    audio.stopAmbient()
                    audio.playOneShot("complete")
                    if (overlay == null) showEffect(connection = false, complete = true, isDemo = false)
                    else overlay?.setCompleted()
                } else if (plugged && !full && completed) {
                    completed = false
                    overlay?.setCharging()
                    if (!screenOff) audio.startAmbient()
                }
            }
        }
        val intent = if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent != null) {
            connected = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            completed = connected && (intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL || level >= scale)
            if (prefs.getBoolean("enabled", true) && connected) {
                if (completed) showEffect(connection = false, complete = true, isDemo = false)
                else scheduleConnectionEffect()
            }
        }
    }

    private fun scheduleConnectionEffect() {
        handler.removeCallbacksAndMessages(CONNECTION_TOKEN)
        if (!connected || completed || screenOff || !prefs.getBoolean("enabled", true)) return
        val delay = prefs.getInt("connectDelay", 2400).coerceIn(0, 3000).toLong()
        handler.postAtTime({
            if (connected && !completed && !screenOff && prefs.getBoolean("enabled", true)) {
                audio.playOneShot("start")
                showEffect(connection = true, complete = false, isDemo = false)
                handler.postDelayed({ if (connected && !completed && !screenOff) audio.startAmbient() }, CONNECTION_MS)
            }
        }, CONNECTION_TOKEN, SystemClock.uptimeMillis() + delay)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra(EXTRA_DEMO, false) == true) {
            demo = true
            handler.removeCallbacksAndMessages(DEMO_TOKEN)
            val delay = prefs.getInt("connectDelay", 2400).coerceIn(0, 3000).toLong()
            handler.postAtTime({
                if (demo && !screenOff) {
                    audio.playOneShot("start", force = true)
                    showEffect(connection = true, complete = false, isDemo = true)
                    handler.postDelayed({ if (demo && !screenOff) audio.startAmbient() }, CONNECTION_MS)
                }
            }, DEMO_TOKEN, SystemClock.uptimeMillis() + delay)
            handler.postAtTime({
                fadeOut()
                audio.stopAmbient()
                demo = false
                if (connected && prefs.getBoolean("enabled", true)) {
                    showEffect(connection = false, complete = completed, isDemo = false)
                    if (!completed && !screenOff) audio.startAmbient()
                } else if (!prefs.getBoolean("enabled", true)) {
                    stopSelf()
                }
            }, DEMO_TOKEN, SystemClock.uptimeMillis() + delay + 8500)
        } else if (intent?.action == ACTION_STOP) {
            stopSelf()
        } else if (!prefs.getBoolean("enabled", true)) {
            fadeOut(); audio.stopAmbient()
        } else if (connected && overlay == null) {
            if (completed) showEffect(connection = false, complete = true, isDemo = false) else scheduleConnectionEffect()
        }
        return START_STICKY
    }

    private fun showEffect(connection: Boolean, complete: Boolean, isDemo: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "مجوز نمایش روی برنامه‌ها لازم است", Toast.LENGTH_SHORT).show()
            return
        }
        removeOverlayImmediately()
        val view = EnergyView(this, prefs) { audio.playArc() }
        view.alpha = 0f
        view.setScreenOff(screenOff && prefs.getBoolean("screenOff", true))
        if (complete) view.setCompleted() else if (connection) view.setConnecting() else view.setCharging()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; format = PixelFormat.TRANSLUCENT }
        try {
            wm?.addView(view, params)
            overlay = view
            view.animate().alpha(1f).setDuration(350).start()
            view.start()
        } catch (_: Exception) {
            overlay = null
            Toast.makeText(this, "نمایش افکت ناموفق بود؛ مجوز و محدودیت‌های باتری را بررسی کن", Toast.LENGTH_LONG).show()
        }
        if (isDemo) handler.postDelayed({ if (demo && !screenOff) audio.startAmbient() }, CONNECTION_MS)
    }

    private fun fadeOut() {
        val old = overlay ?: return
        overlay = null
        old.animate().alpha(0f).setDuration(650).withEndAction {
            try { old.stop(); wm?.removeView(old) } catch (_: Exception) {}
        }.start()
    }

    private fun removeOverlayImmediately() {
        val old = overlay ?: return
        overlay = null
        try { old.animate().cancel(); old.stop(); wm?.removeView(old) } catch (_: Exception) {}
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        when (key) {
            "enabled" -> if (!prefs.getBoolean("enabled", true)) {
                audio.stopAmbient(); fadeOut()
            }
            "ambientSound" -> if (prefs.getBoolean("ambientSound", false) && connected && !completed && !screenOff) audio.startAmbient() else audio.stopAmbient()
            "screenOff" -> overlay?.setScreenOff(screenOff && prefs.getBoolean("screenOff", true))
            "coreImageUri" -> overlay?.reloadCoreImage()
            "soundTheme", "sound_ambient_uri" -> {
                if (connected && !completed && !screenOff && prefs.getBoolean("ambientSound", false)) audio.startAmbient()
            }
            "soundVolume" -> audio.updateAmbientVolume()
            "connectDelay" -> if (connected && overlay == null && !completed) scheduleConnectionEffect()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        connectionPending = false
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        powerReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        batteryReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        removeOverlayImmediately()
        if (::audio.isInitialized) audio.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "mori_charge"
        private const val NOTIFICATION_ID = 9
        private const val EXTRA_DEMO = "demo"
        private const val ACTION_STOP = "com.mori.charginganime.STOP"
        private const val CONNECTION_MS = 3600L
        private val CONNECTION_TOKEN = Any()
        private val DEMO_TOKEN = Any()

        fun showDemo(context: Context) {
            if (!Settings.canDrawOverlays(context)) {
                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}" )).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            }
            val intent = Intent(context, ChargingService::class.java).putExtra(EXTRA_DEMO, true)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}

object MoriAudio {
    fun preview(context: Context, slot: String, prefs: SharedPreferences) {
        MoriAudioController.preview(context, slot, prefs)
    }
}

private class MoriAudioController(private val context: Context, private val prefs: SharedPreferences) {
    private var ambientPlayer: MediaPlayer? = null
    private val pool: SoundPool
    private val arcSamples = mutableListOf<Int>()
    private var released = false

    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(attrs).build()
        val ids = listOf(R.raw.thunder_arc_1, R.raw.thunder_arc_2, R.raw.thunder_arc_3)
        ids.forEach { arcSamples.add(pool.load(context, it, 1)) }
    }

    private fun resourceFor(slot: String): Int {
        val theme = prefs.getString("soundTheme", "cosmic") ?: "cosmic"
        val name = "${theme}_${slot}"
        return context.resources.getIdentifier(name, "raw", context.packageName)
            .takeIf { it != 0 } ?: R.raw.cosmic_start
    }

    fun playOneShot(slot: String, force: Boolean = false) {
        val key = when (slot) { "start" -> "startSound"; "complete" -> "endSound"; else -> "" }
        if (!force && key.isNotEmpty() && !prefs.getBoolean(key, true)) return
        val volume = (prefs.getInt("soundVolume", 75) / 100f).coerceIn(0f, 1f)
        if (volume <= 0f) return
        val saved = prefs.getString("sound_${slot}_uri", null)
        val player = try {
            if (saved != null) MediaPlayer.create(context, Uri.parse(saved)) else MediaPlayer.create(context, resourceFor(slot))
        } catch (_: Exception) { null } ?: return
        try { player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()) } catch (_: Exception) {}
        player.setVolume(volume, volume)
        player.setOnCompletionListener { try { it.release() } catch (_: Exception) {} }
        try { player.start() } catch (_: Exception) { player.release() }
    }

    fun startAmbient() {
        if (released || !prefs.getBoolean("ambientSound", false)) return
        stopAmbient()
        val volume = (prefs.getInt("soundVolume", 75) / 100f).coerceIn(0f, 1f) * .32f
        if (volume <= 0f) return
        val saved = prefs.getString("sound_ambient_uri", null)
        val player = try {
            if (saved != null) MediaPlayer.create(context, Uri.parse(saved)) else MediaPlayer.create(context, resourceFor("ambient"))
        } catch (_: Exception) { null } ?: return
        try {
            player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.isLooping = true
            player.setVolume(volume, volume)
            player.start()
            ambientPlayer = player
        } catch (_: Exception) { player.release() }
    }

    fun stopAmbient() {
        try { ambientPlayer?.stop() } catch (_: Exception) {}
        try { ambientPlayer?.release() } catch (_: Exception) {}
        ambientPlayer = null
    }

    fun updateAmbientVolume() {
        val volume = (prefs.getInt("soundVolume", 75) / 100f).coerceIn(0f, 1f) * .32f
        try { ambientPlayer?.setVolume(volume, volume) } catch (_: Exception) {}
    }

    fun playArc() {
        if (released || !prefs.getBoolean("arcSound", false)) return
        val theme = prefs.getString("soundTheme", "cosmic")
        // The short-strike toggle applies to every sound profile, not only Storm.
        val volume = (prefs.getInt("soundVolume", 75) / 100f).coerceIn(0f, 1f) * .18f
        if (volume <= 0f || arcSamples.isEmpty()) return
        val id = arcSamples.random()
        pool.play(id, volume, volume, 1, 0, 1f)
    }

    fun release() {
        released = true
        stopAmbient()
        try { pool.release() } catch (_: Exception) {}
    }

    companion object {
        fun preview(context: Context, slot: String, prefs: SharedPreferences) {
            val theme = prefs.getString("soundTheme", "cosmic") ?: "cosmic"
            val resName = "${theme}_${slot}"
            val resId = context.resources.getIdentifier(resName, "raw", context.packageName)
            val uri = prefs.getString("sound_${slot}_uri", null)
            val player = try {
                if (uri != null) MediaPlayer.create(context, Uri.parse(uri)) else MediaPlayer.create(context, if (resId != 0) resId else R.raw.cosmic_start)
            } catch (_: Exception) { null } ?: return
            try { player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()) } catch (_: Exception) {}
            val volume = (prefs.getInt("soundVolume", 75) / 100f).coerceIn(0f, 1f)
            player.setVolume(volume, volume)
            player.setOnCompletionListener { try { it.release() } catch (_: Exception) {} }
            try { player.start() } catch (_: Exception) { player.release() }
        }
    }
}

private data class LightningBolt(val main: Path, val branches: List<Path>, val createdAt: Long, val life: Long, val widthDp: Float)

private class EnergyView(
    private val context: Context,
    private val prefs: SharedPreferences,
    private val onArc: () -> Unit
) : View(context) {
    private enum class Mode { CONNECTING, CHARGING, COMPLETE }
    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mode = Mode.CHARGING
    private var running = false
    private var screenDimmed = false
    private var startedAt = 0L
    private var lastStrike = 0L
    private var connectionPath = Path()
    private var connectionForks = mutableListOf<Path>()
    private var connectionLength = 1f
    private var localBolts = mutableListOf<LightningBolt>()
    private var coreBitmap: Bitmap? = null
    private var currentColor: Int = Color.rgb(70, 150, 255)
    private var nextBitmapCheck = 0L
    private val stars = Array(80) { Pair(Random.nextFloat(), Random.nextFloat()) }

    private fun dp(value: Float): Float = value * density
    private fun energyColor(): Int = when (prefs.getString("color", "random")) {
        "gold" -> Color.rgb(255, 190, 80)
        "ice" -> Color.rgb(215, 246, 255)
        "purple" -> Color.rgb(165, 105, 255)
        "blue" -> Color.rgb(65, 150, 255)
        else -> listOf(Color.rgb(65, 150, 255), Color.rgb(165, 105, 255), Color.rgb(220, 245, 255)).random()
    }

    fun start() {
        running = true
        startedAt = SystemClock.uptimeMillis()
        lastStrike = startedAt
        currentColor = energyColor()
        loadUserImage()
        if (mode == Mode.CONNECTING) buildConnectionPath()
        postInvalidateOnAnimation()
    }

    fun stop() { running = false; localBolts.clear(); invalidate() }
    fun reloadCoreImage() { nextBitmapCheck = 0L; loadUserImage(); invalidate() }
    fun setScreenOff(value: Boolean) { screenDimmed = value; invalidate() }
    fun setConnecting() { mode = Mode.CONNECTING; startedAt = SystemClock.uptimeMillis(); buildConnectionPath() }
    fun setCharging() { mode = Mode.CHARGING; startedAt = SystemClock.uptimeMillis(); localBolts.clear(); invalidate() }
    fun setCompleted() { mode = Mode.COMPLETE; startedAt = SystemClock.uptimeMillis(); localBolts.clear(); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0 && mode == Mode.CONNECTING) buildConnectionPath()
    }

    private fun corePoint(): PointF = PointF(width * prefs.getInt("coreX", 50) / 100f, height * prefs.getInt("coreY", 8) / 100f)
    private fun portPoint(): PointF = PointF(width * prefs.getInt("portX", 50) / 100f, height * prefs.getInt("portY", 94) / 100f)
    // UI setting represents diameter in dp; drawing uses radius.
    private fun coreRadius(): Float = dp(prefs.getInt("coreSize", 74).toFloat() * .5f)

    private fun buildConnectionPath() {
        if (width <= 0 || height <= 0) return
        val core = corePoint(); val port = portPoint(); val r = coreRadius()
        val sideX = if (port.x < width / 2f) width * .055f else width * .945f
        val edgeY = (core.y + r * 1.15f).coerceAtMost(height * .85f)
        val path = Path().apply { moveTo(port.x, port.y) }
        appendLightningSegment(path, PointF(port.x, port.y), PointF(sideX, port.y), 7, dp(5f))
        appendLightningSegment(path, PointF(sideX, port.y), PointF(sideX, edgeY), 32, dp(8f))
        appendLightningSegment(path, PointF(sideX, edgeY), PointF(core.x, core.y), 18, dp(11f))
        // Add short, irregular side forks along the edge-travel portion to resemble a natural strike.
        connectionForks.clear()
        val forkCount = Random.nextInt(3, 6)
        repeat(forkCount) {
            val f = Random.nextFloat() * .72f + .12f
            val anchor = PointF(sideX, port.y + (edgeY - port.y) * f)
            val forkSide = if (Random.nextBoolean()) 1f else -1f
            val forkEnd = PointF(anchor.x + forkSide * dp(Random.nextInt(12, 38).toFloat()), anchor.y + dp(Random.nextInt(-28, 29).toFloat()))
            val branch = Path().apply { moveTo(anchor.x, anchor.y) }
            appendLightningSegment(branch, anchor, forkEnd, Random.nextInt(4, 8), dp(5f))
            connectionForks.add(branch)
        }
        connectionPath = path
        val measure = android.graphics.PathMeasure(path, false)
        connectionLength = measure.length.coerceAtLeast(1f)
    }

    private fun appendJagged(path: Path, from: PointF, to: PointF, steps: Int, jitter: Float) {
        appendLightningSegment(path, from, to, steps, jitter)
    }

    // Uneven, sharply angled segments with occasional offset, avoiding the regular zig-zag look.
    private fun appendLightningSegment(path: Path, from: PointF, to: PointF, steps: Int, jitter: Float) {
        val dx = to.x - from.x; val dy = to.y - from.y
        val length = hypot(dx, dy).coerceAtLeast(1f)
        val nx = -dy / length; val ny = dx / length
        for (i in 1 until steps) {
            val f = i.toFloat() / steps
            val envelope = sin(f * PI.toFloat()).coerceAtLeast(.12f)
            val offset = (Random.nextFloat() - .5f) * jitter * 2f * envelope
            path.lineTo(from.x + dx * f + nx * offset, from.y + dy * f + ny * offset)
        }
        path.lineTo(to.x, to.y)
    }

    private fun createLocalBolt(center: PointF, radius: Float, direction: Float): LightningBolt {
        // Each strike is assigned a specific direction sector, so the core does not emit a radial ring.
        val startAngle = direction + (Random.nextFloat() - .5f) * .42f
        val length = radius * (Random.nextFloat() * .48f + .34f)
        val angle = startAngle + (Random.nextFloat() - .5f) * .72f
        val startR = radius * (Random.nextFloat() * .28f + .42f)
        val endR = startR + length
        val sx = center.x + cos(startAngle) * startR
        val sy = center.y + sin(startAngle) * startR
        val ex = center.x + cos(angle) * endR
        val ey = center.y + sin(angle) * endR
        val steps = Random.nextInt(5, 10)
        val points = ArrayList<PointF>()
        for (i in 0..steps) {
            val f = i.toFloat() / steps
            val spread = dp(8f + Random.nextFloat() * 10f) * (1f - abs(.5f - f))
            points.add(PointF(sx + (ex - sx) * f + (Random.nextFloat() - .5f) * spread,
                sy + (ey - sy) * f + (Random.nextFloat() - .5f) * spread))
        }
        val main = Path().apply { moveTo(points[0].x, points[0].y); for (i in 1 until points.size) lineTo(points[i].x, points[i].y) }
        val branches = mutableListOf<Path>()
        val count = Random.nextInt(1, 3)
        repeat(count) {
            val anchorIndex = Random.nextInt(2, (points.size - 1).coerceAtLeast(3))
            val a = points[anchorIndex]
            val branchAngle = atan2(ey - sy, ex - sx) + (if (Random.nextBoolean()) 1f else -1f) * Random.nextFloat() * 1.6f
            val branchLength = length * (Random.nextFloat() * .25f + .10f)
            val end = PointF(a.x + cos(branchAngle) * branchLength, a.y + sin(branchAngle) * branchLength)
            val b = Path().apply { moveTo(a.x, a.y) }
            appendJagged(b, a, end, Random.nextInt(2, 5), dp(5f))
            branches.add(b)
        }
        return LightningBolt(main, branches, SystemClock.uptimeMillis(), Random.nextLong(65L, 170L), Random.nextFloat() * .8f + .7f)
    }

    private fun buildNewStrike(now: Long) {
        val center = corePoint(); val radius = coreRadius()
        // A strike event chooses only 2-3 different directions, rather than firing in every direction.
        val density = prefs.getInt("branches", 7).coerceIn(2, 14)
        val boltCount = if (mode == Mode.COMPLETE) 0 else if (density < 8) Random.nextInt(2, 3) else Random.nextInt(2, 4)
        val sectorCount = 8
        val sectors = (0 until sectorCount).shuffled().take(boltCount)
        sectors.forEach { sector ->
            val direction = (sector * (2f * PI.toFloat() / sectorCount)) - PI.toFloat() + (Random.nextFloat() - .5f) * .22f
            localBolts.add(createLocalBolt(center, radius, direction))
        }
        if (prefs.getBoolean("particles", true)) {
            // particles are redrawn procedurally around the core; no full-screen paths are generated
        }
        lastStrike = now
        if (prefs.getString("color", "random") == "random") currentColor = energyColor()
        if (mode != Mode.COMPLETE) onArc()
    }

    private fun loadUserImage() {
        val now = SystemClock.uptimeMillis()
        if (now < nextBitmapCheck) return
        nextBitmapCheck = now + 8000
        val value = prefs.getString("coreImageUri", null) ?: run { coreBitmap = null; return }
        try {
            val uri = Uri.parse(value)
            val resolver = context.contentResolver
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            val largest = max(opts.outWidth, opts.outHeight).coerceAtLeast(256)
            opts.inSampleSize = max(1, largest / 256)
            opts.inJustDecodeBounds = false
            resolver.openInputStream(uri)?.use { coreBitmap = BitmapFactory.decodeStream(it, null, opts) }
        } catch (_: Exception) { coreBitmap = null }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running || width <= 0 || height <= 0) return
        val now = SystemClock.uptimeMillis()
        val elapsed = now - startedAt
        val center = corePoint()
        val radius = coreRadius()
        val color = currentColor
        val intensity = prefs.getInt("intensity", 3).coerceIn(1, 5)

        // The window remains transparent; the current phone screen is always the background.
        if (screenDimmed) {
            drawCore(canvas, center, radius, color, elapsed, intensity, .22f)
            postInvalidateDelayed(450)
            return
        }

        if (mode == Mode.CONNECTING) {
            val fraction = (elapsed / 2050f).coerceIn(0f, 1f)
            drawConnection(canvas, fraction, color, intensity)
            if (fraction >= 1f) {
                drawImpactBurst(canvas, center, radius, color, intensity, elapsed)
                if (elapsed > 3600L) { mode = Mode.CHARGING; startedAt = now; lastStrike = now - 100L }
            }
        } else if (mode == Mode.CHARGING) {
            val wait = (1050 - prefs.getInt("speed", 5) * 65).coerceAtLeast(330)
            if (now - lastStrike > wait) buildNewStrike(now)
            val iterator = localBolts.iterator()
            while (iterator.hasNext()) {
                val bolt = iterator.next()
                val age = now - bolt.createdAt
                if (age > bolt.life) iterator.remove() else drawLocalBolt(canvas, bolt, color, (1f - age.toFloat() / bolt.life).coerceIn(0f, 1f), intensity)
            }
        } else {
            // Fully charged: no storm. Keep only a slow, restrained afterglow.
            if (prefs.getBoolean("pulses", true)) drawCompletionWave(canvas, center, radius, color, elapsed)
        }

        drawCore(canvas, center, radius, color, elapsed, intensity, if (mode == Mode.COMPLETE) .68f else 1f)
        if (prefs.getBoolean("particles", true) && mode != Mode.COMPLETE) drawParticles(canvas, center, radius, color, elapsed, intensity)
        if (running) postInvalidateDelayed(if (mode == Mode.COMPLETE) 70L else 33L)
    }

    private fun drawConnection(canvas: Canvas, fraction: Float, color: Int, intensity: Int) {
        val measure = android.graphics.PathMeasure(connectionPath, false)
        val path = Path()
        measure.getSegment(0f, connectionLength * fraction, path, true)
        drawElectricPath(canvas, path, color, 1f, dp(1.65f + intensity * .18f))
        connectionForks.forEach { fork -> drawElectricPath(canvas, fork, color, .78f, dp(1.05f)) }
        if (fraction > .72f) {
            val c = corePoint()
            repeat(2) { index ->
                val branch = Path().apply { moveTo(c.x + (index - .5f) * dp(5f), c.y + dp(5f)); lineTo(c.x + (index - .5f) * dp(28f), c.y + dp(Random.nextFloat() * 35f - 18f)) }
                drawElectricPath(canvas, branch, color, (fraction - .72f) / .28f, dp(1.3f))
            }
        }
    }

    private fun drawLocalBolt(canvas: Canvas, bolt: LightningBolt, color: Int, alpha: Float, intensity: Int) {
        drawElectricPath(canvas, bolt.main, color, alpha, dp(bolt.widthDp + intensity * .25f))
        bolt.branches.forEach { drawElectricPath(canvas, it, color, alpha * .9f, dp(1.1f)) }
    }

    private fun drawElectricPath(canvas: Canvas, path: Path, color: Int, alpha: Float, widthPx: Float) {
        val a = (255 * alpha).toInt().coerceIn(0, 255)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        // A soft, narrow glow rather than the heavy outlined stroke used in earlier builds.
        p.color = (color and 0x00FFFFFF) or ((a * .72f).toInt().coerceIn(0,255) shl 24)
        p.strokeWidth = widthPx * 2.7f
        p.setShadowLayer(max(dp(2f), widthPx * 2.6f), 0f, 0f, color)
        canvas.drawPath(path, p)
        p.clearShadowLayer()
        p.color = (color and 0x00FFFFFF) or ((min(255, (a * 1.15f).toInt())) shl 24)
        p.strokeWidth = widthPx * 1.45f
        canvas.drawPath(path, p)
        p.color = (Color.WHITE and 0x00FFFFFF) or ((a * .78f).toInt() shl 24)
        p.strokeWidth = max(dp(.55f), widthPx * .52f)
        canvas.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    private fun drawImpactBurst(canvas: Canvas, c: PointF, radius: Float, color: Int, intensity: Int, elapsed: Long) {
        val phase = ((elapsed - 2050L) / 1500f).coerceIn(0f, 1f)
        val burst = radius * (0.65f + phase * 1.8f)
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.6f); p.color = Color.argb((130 * (1f - phase)).toInt(), 180, 214, 255)
        canvas.drawCircle(c.x, c.y, burst, p)
        repeat(13) { i ->
            val a = i * (Math.PI.toFloat() * 2f / 13f) + .17f
            val r1 = radius * .48f
            val r2 = min(width, height) * (.12f + phase * .24f) * (0.72f + Random.nextFloat() * .45f)
            val end = PointF(c.x + cos(a) * r2, c.y + sin(a) * r2)
            val start = PointF(c.x + cos(a) * r1, c.y + sin(a) * r1)
            val ray = Path().apply { moveTo(start.x, start.y) }
            appendJagged(ray, start, end, 6, dp(7f))
            drawElectricPath(canvas, ray, color, (1f - phase) * .75f, dp(1.2f + intensity * .18f))
        }
        p.style = Paint.Style.FILL
    }

    private fun drawCore(canvas: Canvas, c: PointF, radius: Float, color: Int, elapsed: Long, intensity: Int, alpha: Float) {
        val pulse = if (prefs.getBoolean("pulses", true)) 1f + .045f * sin(elapsed / 370.0).toFloat() else 1f
        val r = radius * pulse
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(c.x, c.y, r * 2.15f,
            intArrayOf(Color.argb((70 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb((25 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT),
            floatArrayOf(0f, .52f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(c.x, c.y, r * 2.15f, p); p.shader = null

        p.color = Color.argb((95 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        p.setShadowLayer(dp(22f + intensity * 3f), 0f, 0f, Color.argb((220 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color)))
        canvas.drawCircle(c.x, c.y, r * .8f, p); p.clearShadowLayer()

        // Accretion rings: layered, tilted and rotating rather than a single oval.
        canvas.save(); canvas.rotate((elapsed * .018f) % 360f, c.x, c.y)
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(2.2f); p.color = Color.argb((205 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color)); p.setShadowLayer(dp(9f), 0f, 0f, color)
        canvas.drawOval(RectF(c.x - r * 1.24f, c.y - r * .38f, c.x + r * 1.24f, c.y + r * .38f), p)
        p.clearShadowLayer(); p.strokeWidth = dp(1.1f); p.color = Color.argb((135 * alpha).toInt(), 205, 225, 255)
        canvas.drawOval(RectF(c.x - r * .97f, c.y - r * .22f, c.x + r * .97f, c.y + r * .22f), p)
        canvas.restore()
        canvas.save(); canvas.rotate(-27f - (elapsed * .009f) % 360f, c.x, c.y)
        p.strokeWidth = dp(1.4f); p.color = Color.argb((110 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawOval(RectF(c.x - r * 1.42f, c.y - r * .17f, c.x + r * 1.42f, c.y + r * .17f), p)
        canvas.restore(); p.style = Paint.Style.FILL

        p.shader = RadialGradient(c.x, c.y, r * .65f, intArrayOf(Color.rgb(1, 2, 8), Color.rgb(2, 5, 16), Color.rgb(15, 20, 43)), floatArrayOf(0f, .72f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(c.x, c.y, r * .57f, p); p.shader = null
        p.color = Color.BLACK; canvas.drawCircle(c.x, c.y, r * .36f, p)
        // Thin, irregular-looking bright rim and offset energy corona around the event horizon.
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.25f)
        p.color = Color.argb((180 * alpha).toInt(), 210, 235, 255)
        canvas.drawCircle(c.x, c.y, r * .39f, p)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(c.x - r * .14f, c.y - r * .16f, r * .48f,
            intArrayOf(Color.argb((85 * alpha).toInt(), 190, 225, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(c.x, c.y, r * .46f, p); p.shader = null

        val bitmap = coreBitmap
        if (bitmap != null && !bitmap.isRecycled) {
            val clip = Path().apply { addCircle(c.x, c.y, r * .48f, Path.Direction.CW) }
            canvas.save(); canvas.clipPath(clip)
            val dst = RectF(c.x - r * .48f, c.y - r * .48f, c.x + r * .48f, c.y + r * .48f)
            p.alpha = (240 * alpha).toInt(); canvas.drawBitmap(bitmap, null, dst, p); p.alpha = 255
            canvas.restore()
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f); p.color = Color.argb((175 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawCircle(c.x, c.y, r * .59f, p); p.style = Paint.Style.FILL
    }

    private fun drawParticles(canvas: Canvas, c: PointF, radius: Float, color: Int, elapsed: Long, intensity: Int) {
        val phase = elapsed / 1100f
        stars.take(26 + intensity * 5).forEachIndexed { index, pair ->
            val angle = pair.first * Math.PI.toFloat() * 2f + phase * (if (index % 2 == 0) .3f else -.2f)
            val distance = radius * (1.15f + pair.second * 1.6f)
            val x = c.x + cos(angle) * distance
            val y = c.y + sin(angle) * distance * .72f
            val alpha = (70 + 90 * (0.5 + 0.5 * sin(phase * 2 + index)).toFloat()).toInt()
            p.color = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
            canvas.drawCircle(x, y, dp(if (index % 6 == 0) 1.8f else .9f), p)
        }
    }

    private fun drawCompletionWave(canvas: Canvas, c: PointF, radius: Float, color: Int, elapsed: Long) {
        val phase = (elapsed % 2800L) / 2800f
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.3f)
        p.color = Color.argb((75 * (1f - phase)).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawCircle(c.x, c.y, radius * (1.0f + phase * 1.1f), p)
        p.style = Paint.Style.FILL
    }
}
