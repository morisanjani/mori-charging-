package com.mori.charginganime

import android.app.*
import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.Toast
import kotlin.random.Random

class ChargingService:Service(){
    private var receiver:BroadcastReceiver?=null
    private var overlay:EnergyView?=null
    private var wm:WindowManager?=null
    private val channel="mori_charge"
    private val prefs by lazy{getSharedPreferences("mori",MODE_PRIVATE)}
    override fun onCreate(){
        super.onCreate();createChannel()
        val n=Notification.Builder(this,channel).setContentTitle("Mori Charging Anime").setContentText("سرویس آماده به کار").setSmallIcon(android.R.drawable.ic_lock_idle_charging).build()
        startForeground(9,n)
        receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){when(i?.action){Intent.ACTION_POWER_CONNECTED->if(prefs.getBoolean("enabled",true))showEffect(false);Intent.ACTION_POWER_DISCONNECTED->fadeOut()}}}
        val f=IntentFilter().apply{addAction(Intent.ACTION_POWER_CONNECTED);addAction(Intent.ACTION_POWER_DISCONNECTED)}
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED)else registerReceiver(receiver,f)
    }
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel(channel,"Mori Charging",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager::class.java).createNotificationChannel(ch)}}
    override fun onStartCommand(i:Intent?,f:Int,s:Int):Int { if(i?.getBooleanExtra("demo",false)==true) showEffect(true); return START_STICKY }
    private fun showEffect(demo:Boolean){
        if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"برای افکت مجوز نمایش روی برنامه‌ها لازم است",Toast.LENGTH_SHORT).show();return}
        fadeOut();wm=getSystemService(WINDOW_SERVICE) as WindowManager
        overlay=EnergyView(this,prefs,demo)
        val type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.START
        try{wm?.addView(overlay,p);overlay?.start()}catch(e:Exception){Toast.makeText(this,"Overlay ناموفق: ${e.message}",Toast.LENGTH_SHORT).show()}
    }
    private fun fadeOut(){try{overlay?.stop();wm?.removeView(overlay)}catch(_:Exception){};overlay=null}
    override fun onDestroy(){receiver?.let{try{unregisterReceiver(it)}catch(_:Exception){}};fadeOut();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
    override fun onBind(i:Intent?):IBinder?=null
    companion object{
        fun showDemo(c:Context){
            if(Settings.canDrawOverlays(c)){
                val svc=Intent(c,ChargingService::class.java).putExtra("demo",true)
                if(Build.VERSION.SDK_INT>=26)c.startForegroundService(svc) else c.startService(svc)
            }else c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
class EnergyView(c:Context,private val prefs:android.content.SharedPreferences,private val demo:Boolean):View(c){
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var t0=0L;private var running=false
    private val chosen=when(prefs.getString("color","random")){"gold"->Color.rgb(255,195,65);"ice"->Color.rgb(220,245,255);"blue"->Color.rgb(70,150,255);else->if(Random.nextBoolean())Color.rgb(70,150,255)else Color.rgb(255,195,65)}
    private val paths=ArrayList<Path>()
    fun start(){running=true;t0=SystemClock.uptimeMillis();makePaths();invalidate()}
    fun stop(){running=false;invalidate()}
    private fun makePaths(){
        paths.clear();val w=width.toFloat().coerceAtLeast(1f);val h=height.toFloat().coerceAtLeast(1f);val cx=w/2;val cy=h*.14f
        val count=3+prefs.getInt("intensity",2)
        repeat(count){sideIndex->
            val left=sideIndex%2==0;val startX=if(left)w*.04f else w*.96f
            val p=Path().apply{moveTo(startX,h*.9f);var x=startX;var y=h*.9f
                repeat(9){y-=h*.075f;x+=(if(left)1 else -1)*Random.nextFloat()*w*.055f;lineTo(x,y)}
                lineTo(cx+(if(left)-1 else 1)*w*.12f,cy+h*.18f);lineTo(cx,cy)}
            paths.add(p)
        }
    }
    override fun onDraw(canvas:Canvas){
        if(!running)return
        val elapsed=SystemClock.uptimeMillis()-t0;val w=width.toFloat();val h=height.toFloat();val cx=w/2;val cy=h*.13f
        val strength=(prefs.getInt("intensity",2)+1).toFloat()
        canvas.drawColor(Color.TRANSPARENT)
        // Brief intro bolt paths; then small intermittent edge flashes.
        if(elapsed<2600){
            paint.style=Paint.Style.STROKE;paint.strokeWidth=1.5f+strength;paint.color=chosen;paint.setShadowLayer(15f*strength,0f,0f,chosen)
            paths.forEach{canvas.drawPath(it,paint)}
        }else if(elapsed%1300<95){
            paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=chosen;paint.setShadowLayer(9f,0f,0f,chosen)
            val flash=Path().apply{moveTo(w*.05f,h*.3f);lineTo(w*.12f,h*.28f);lineTo(w*.10f,h*.25f);lineTo(w*.19f,h*.21f)}
            canvas.drawPath(flash,paint)
        }
        paint.clearShadowLayer()
        // Core and spinning ring
        paint.style=Paint.Style.FILL;paint.color=Color.BLACK
        canvas.drawOval(RectF(cx-43,cy-20,cx+43,cy+20),paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=3f+strength;paint.color=chosen;paint.setShadowLayer(18f,chosen,0f,0f)
        val ring=RectF(cx-72,cy-29,cx+72,cy+29);canvas.save();canvas.rotate((elapsed/15f)%360,cx,cy);canvas.drawOval(ring,paint);canvas.restore()
        paint.clearShadowLayer()
        if(demo&&elapsed>5500){running=false;return}
        postInvalidateDelayed(32)
    }
}