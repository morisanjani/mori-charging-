package com.mori.charginganime

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.SharedPreferences

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        prefs=getSharedPreferences("mori",MODE_PRIVATE)
        render()
    }
    private fun render(){
        val layout=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(20));setBackgroundColor(Color.rgb(5,6,9))}
        val title=TextView(this).apply{text="MORI  •  CHARGING ANIME\\n\\nتنظیمات هسته";textSize=23f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,0,0,dp(22))}
        layout.addView(title)
        layout.addView(label("کنترل افکت و صدا"))
        addSwitch(layout,"فعال بودن برنامه","enabled",true)
        addSwitch(layout,"صدای شروع","startSound",true)
        addSwitch(layout,"صدای شارژ کامل","endSound",true)
        addSwitch(layout,"افکت هنگام خاموش بودن صفحه (آزمایشی)","screenOff",false)
        layout.addView(label("رنگ انرژی"))
        val colors=arrayOf("تصادفی","آبی","طلایی","سفید یخی")
        val colorValues=arrayOf("random","blue","gold","ice")
        val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,colors)
        spinner.setSelection(colorValues.indexOf(prefs.getString("color","random")).coerceAtLeast(0))
        spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:android.widget.AdapterView<*>?){}
            override fun onItemSelected(p:android.widget.AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){prefs.edit().putString("color",colorValues[pos]).apply()}
        }
        layout.addView(spinner)
        layout.addView(label("شدت افکت"))
        val seek=SeekBar(this).apply{max=4;progress=prefs.getInt("intensity",2)}
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){prefs.edit().putInt("intensity",p).apply()}
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })
        layout.addView(seek)
        layout.addView(button("اجازه نمایش روی برنامه‌ها",Color.rgb(35,52,75)){if(!Settings.canDrawOverlays(this))startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))})
        layout.addView(button("تست افکت شارژ",Color.rgb(28,66,100)){ChargingService.showDemo(this)})
        layout.addView(button("فعال‌سازی سرویس",Color.rgb(25,35,48)){startService(Intent(this,ChargingService::class.java))})
        layout.addView(button("توقف سرویس",Color.rgb(35,35,40)){stopService(Intent(this,ChargingService::class.java))})
        layout.addView(label("این نسخه آزمایشی است. عملکرد صفحه خاموش/AOD، محدودیت‌های پس‌زمینه و سازگاری HyperOS نیازمند تست روی گوشی هستند."))
        setContentView(ScrollView(this).apply{addView(layout)})
    }
    private fun label(s:String)=TextView(this).apply{text=s;setTextColor(Color.LTGRAY);textSize=13f;setPadding(0,dp(12),0,dp(8))}
    private fun button(s:String,c:Int,action:()->Unit)=Button(this).apply{text=s;setBackgroundColor(c);setTextColor(Color.WHITE);setOnClickListener{action()}}
    private fun addSwitch(parent:LinearLayout,title:String,key:String,default:Boolean){
        val sw=Switch(this).apply{text=title;setTextColor(Color.WHITE);isChecked=prefs.getBoolean(key,default)}
        sw.setOnCheckedChangeListener{_,checked->prefs.edit().putBoolean(key,checked).apply()}
        parent.addView(sw)
    }
}