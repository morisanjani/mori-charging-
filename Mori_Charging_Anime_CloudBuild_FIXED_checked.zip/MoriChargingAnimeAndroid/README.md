# Mori Charging Anime — Android starter v0.2
The starter includes a basic settings screen, persistent toggle/color/intensity preferences, overlay-permission prompt, foreground service, charging/disconnect broadcast handling, and a timed visual overlay test.
This is source code, not an APK; it has not been compiled or device-tested. Screen-off behavior and OEM background restrictions remain unverified. Sound, production icon, and more elaborate cinematic rendering remain planned.
